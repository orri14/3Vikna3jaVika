﻿using Xamarin.Forms;

namespace MovieSearch
{

    public class SearchPage : ContentPage
    {

        
    }
}